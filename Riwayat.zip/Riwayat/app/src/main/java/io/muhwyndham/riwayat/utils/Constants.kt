package io.muhwyndham.riwayat.utils

class Constants {
    companion object{
        const val RC_SIGN_IN = 101
    }
}